﻿using Otus.ToDoList.ConsoleBot;
using Otus.ToDoList.ConsoleBot.Types;
using System;

namespace Homework2
{
    internal class Program
    {
        public const string ProgrammVersionInfo = "версия 1.0, 17.02.2026";

        static void Main(string[] args)
        {
            try
            {
                var handler = new UpdateHandler();
                var botClient = new ConsoleBotClient();
                botClient.StartReceiving(handler);
            }
            catch (Exception exp)
            {
                Console.WriteLine($"Произошла непредвиденная ошибка:");
                Console.WriteLine($"Тип: {exp.GetType().FullName}");
                Console.WriteLine($"Исключение: {exp.Message}");
                Console.WriteLine($"Трассировка стека: {exp.StackTrace}");
                Console.WriteLine($"Информация об исключении: {exp.InnerException}");
            }
        }
    }
}