﻿using Otus.ToDoList.ConsoleBot;
using Otus.ToDoList.ConsoleBot.Types;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Homework2
{
    public class UserService : IUserService
    {
        private Dictionary<long, ToDoUser> _users;
        public ToDoUser? GetUser(long telegramUserId)
        {
            //Заполнять telegramUserId и telegramUserName нужно из значений Update.Message.From
            if (_users.TryGetValue(telegramUserId, out ToDoUser user))
            {  
                return user; 
            }
            else
            {
                return null;
            }
        
        }

        public ToDoUser RegisterUser(long telegramUserId, string telegramUserName)
        {
            ToDoUser user = new ToDoUser(telegramUserName, telegramUserId);
            _users.Add(telegramUserId, user);
            return user;
        }
    }
}
