﻿using Otus.ToDoList.ConsoleBot;
using Otus.ToDoList.ConsoleBot.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Runtime.Intrinsics.X86;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace Homework2
{
    
    public class UpdateHandler : IUpdateHandler
    {
        private const int Min = 1;
        private const int Max = 100;

        private readonly List<ToDoItem> tasks = new();
        private int taskCountLimit = 0;
        private int taskLengthLimit = 0;
        private ToDoUser user;
        public IUserService _userService;

        public UpdateHandler(IUserService userService)
        {
            _userService = userService;
        }

        public void HandleUpdateAsync(ITelegramBotClient botClient, Update update)
        {
            try
            {
                botClient.SendMessage(update.Message.Chat, "Выберите нужную команду!");
                botClient.SendMessage(update.Message.Chat, @"/start /help /info /addtask /completetask /showtasks /showalltasks /removetask /exit");

                //string taskLength = string.Empty;
                if (taskCountLimit == 0)
                {
                    botClient.SendMessage(update.Message.Chat, "Введите максимально допустимое количество задач (от 1 до 100):");
                    var maxNumber = Console.ReadLine();
                    taskCountLimit = ParseAndValidateInt(maxNumber);
                    botClient.SendMessage(update.Message.Chat, $"Максимальное количество задач: {taskCountLimit}");
                }

                if (taskLengthLimit == 0)
                {
                    botClient.SendMessage(update.Message.Chat, "Введите максимально допустимую длину задачи (от 1 до 100):");
                    var taskLength = Console.ReadLine();
                    taskLengthLimit = ParseAndValidateInt(taskLength);
                    botClient.SendMessage(update.Message.Chat, $"Максимальная длина задачи: {taskLengthLimit}");
                }


                var splitInput = update.Message.Text?.Split(' ');
                if (splitInput == null || splitInput.Length < 1)
                {
                    botClient.SendMessage(update.Message.Chat,
                        "Такой команды нет. Пожалуйста, введите команду из предложенных:"
                        + Environment.NewLine
                        + @"/start /help /info /addtask /showtasks /removetask /exit");
                    return;
                }

                switch (splitInput[0])
                {
                    case "/start":
                        var user = _userService.GetUser(update.Message.From.Id);
                        if (user == null)
                        {
                            _userService.RegisterUser(update.Message.From.Id, update.Message.From.Username);
                        }
                        //var userName = GetNameMethod(botClient, update.Message.Chat);
                        //user = new ToDoUser(userName, 0);  //  1 пункт
                        botClient.SendMessage(update.Message.Chat, $"Здравствуйте, {update.Message.From.Username}! Чем я могу помочь?");
                        break;

                    case "/help":
                        //  Отображает краткую справочную информацию о том, как пользоваться программой.
                        HelpMethod(botClient, update.Message.Chat);
                        break;

                    case "/info":
                        //  Предоставляет информацию о версии программы и дате её создания.
                        InfoMethod(botClient, update.Message.Chat);
                        break;

                    case "/addtask":
                        AddTaskMethod(tasks, taskCountLimit, taskLengthLimit, botClient, update.Message.Chat);
                        break;

                    case "/showtasks":
                        ShowTasksMethod(tasks, botClient, update.Message.Chat);
                        break;

                    case "/removetask":
                        RemoveTaskMethod(tasks, botClient, update.Message.Chat);
                        break;

                    case "/completetask":
                        //Найти задачу по Id
                        //Обновить State на ToDoItemState.Completed
                        //Обновить StateChangedAt
                        //Пример: / completetask 73c7940a - ca8c - 4327 - 8a15 - 9119bffd1d5e
                        var idToFind = string.Join(' ', splitInput[1..]);
                        ValidateString(idToFind);
                        if (Guid.TryParse(idToFind, out Guid idSearch)) ;
                        {
                            ToDoItem foundTask = tasks.Find(t => t.Id == idSearch);
                            foundTask.State = ToDoItemState.Completed;
                            foundTask.StateChangedAt = DateTime.UtcNow;
                            botClient.SendMessage(update.Message.Chat, "Задача завершена.");
                        }
                        break;

                    case "/showalltasks":
                        //Добавить обработку новой команды / showalltasks.По ней выводить команды с любым State и добавить State в вывод
                        //Пример: (Active)Имя задачи - 01.01.2025 00:00:00 - ffbfe448 - 4b39 - 4778 - 98aa - 1aed98f7eed8
                        ShowAllTasks(tasks, true, botClient, update.Message.Chat);
                        break;

                    case "/exit":
                        break;

                    default:

                        break;
                }

            }
            catch (TaskCountLimitException e)
            {
                botClient.SendMessage(update.Message.Chat, $"Исключение: {e.Message}");
            }
            catch (TaskLengthLimitException e)
            {
                botClient.SendMessage(update.Message.Chat, $"Исключение: {e.Message}");
            }
            catch (DuplicateTaskException e)
            {
                botClient.SendMessage(update.Message.Chat, $"Исключение: {e.Message}");
            }
            catch (ArgumentException e)
            {
                botClient.SendMessage(update.Message.Chat, $"Ошибка: {e.Message}");
            }
        }

        private void InfoMethod(ITelegramBotClient botClient, Chat chat)
        {
            botClient.SendMessage(chat,
                $"{((user == null)
                ? "Пожалуйста, начните с команды /start."
                : $"{user?.TelegramUserName}, версия и дата создания: {Program.ProgrammVersionInfo}")}"
                );
        }

        private void HelpMethod(ITelegramBotClient botClient, Chat chat)
        {
            botClient.SendMessage(chat,
                $"{((user == null) 
                ? "Пожалуйста, начните с команды /start."
                : $"{user?.TelegramUserName}," +
                $"\nкоманда /help позволяет получить краткую справочную информацию о том, как пользоваться программой," +
                $"\nкоманда /info позволяет получить информацию о версии программы и дате её создания, " +
                $"\nкоманда /addtask позволяет добавлять задачи," +
                $"\nкоманда /completetask меняет статус задачи на completed," +
                $"\nкоманда /showtasks выводит список введенных задач со статусом Active, " +
                $"\nкоманда /showalltasks выводит список всех введенных задач, " +
                $"\nкоманда /removetask позволяет удалить определенную задачу," +
                $"\nкоманда /exit позволяет выйти из меню.")}");
        }

        private void RemoveTaskMethod(List<ToDoItem> tasks, ITelegramBotClient botClient, Chat chat)
        {
            bool valid = false;
            do
            {
                if (tasks != null && tasks.Count > 0)
                {
                    botClient.SendMessage(chat, "Введите номер задачи, которую хотите удалить:");
                    ShowAllTasks(tasks, true, botClient, chat);
                    var taskNumberToRemove = Console.ReadLine();
                    int taskNumber;

                    if (!int.TryParse(taskNumberToRemove, out taskNumber))
                    {
                        botClient.SendMessage(chat, "Число не распознано.");
                        continue;
                    }
                    int indexToRemove = taskNumber - 1;

                    if (indexToRemove >= 0 && indexToRemove < tasks.Count)
                    {
                        valid = true;
                        var removedTaskName = tasks[taskNumber - 1];
                        tasks.RemoveAt(indexToRemove);
                        botClient.SendMessage(chat, $"Задача '{removedTaskName}' удалена.");
                    }
                    else
                    {
                        botClient.SendMessage(chat, "Элемент с таким номером не существует. Пожалуйста, введите корректный номер.");
                    }
                }
                else
                {
                    botClient.SendMessage(chat, "Список пуст.");
                }
            } while (!valid);
        }

        private void ShowTasksMethod(List<ToDoItem> tasks, ITelegramBotClient botClient, Chat chat)
        {
            if (tasks != null && tasks.Count > 0)
            {
                botClient.SendMessage(chat, "Вот Ваш список задач:");
                ShowAllTasks(tasks, false, botClient, chat);
            }
            else
            {
                botClient.SendMessage(chat, "Список пуст.");
            }
        }

        private void AddTaskMethod(List<ToDoItem> tasks, int taskCountLimit, int taskLengthLimit, ITelegramBotClient botClient, Chat chat)
        {
            bool isValid = false;
            if (tasks.Count >= taskCountLimit)
            {
                throw new TaskCountLimitException(taskCountLimit);
            }

            do
            {
                botClient.SendMessage(chat, "Пожалуйста, введите описание задачи:");
                var task = Console.ReadLine();
                int length = task.Length;
                ValidateString(task);
                bool alreadyExist = tasks.Any(t => t.Name == task);

                if (task.Length > taskLengthLimit)
                {
                    throw new TaskLengthLimitException(task.Length, taskLengthLimit);
                }
                else if (alreadyExist)
                {
                    throw new DuplicateTaskException(task);
                }
                else
                {
                    isValid = true;
                    tasks.Add(new ToDoItem(user, task));  //  2 пункт
                    botClient.SendMessage(chat, $"Задача '{task}' добавлена.");  //  2 пункт
                }
            } while (!isValid);
        }

        public void ShowAllTasks(List<ToDoItem> tasks, bool showAll, ITelegramBotClient botClient, Chat chat)
        {
            int taskIndex = 1;
            if (tasks?.Count > 0)
            {
                foreach (var task in tasks)
                {
                    if (showAll)
                    {
                        botClient.SendMessage(chat, $"{taskIndex++} {task.State} {task.Name} {task.CreatedAt} {task.Id}");
                    }
                    else if (task.State == ToDoItemState.Active)
                    {
                        botClient.SendMessage(chat, $"{taskIndex++} {task.Name} {task.CreatedAt} {task.Id}");
                    }
                }
            }
            else
            {
                botClient.SendMessage(chat, "Список пуст.");
            }
        }

        public string? GetNameMethod(ITelegramBotClient botClient, Chat chat)
        {
            botClient.SendMessage(chat, "Пожалуйста, введите свое имя:");
            var name = Console.ReadLine();
            ValidateString(name);

            return name;
        }

        private int ParseAndValidateInt(string? str, int min = 1, int max = 100)
        {
            int strInt = 0;
            if (!int.TryParse(str, out strInt))
            {
                throw new ArgumentException("Введено не число.");
            }
            if (strInt > max || strInt < min)
            {
                throw new ArgumentException("Длинна введенных данных не соответсвует диапазону (от 1 до 100).");
            }
            return strInt;
        }

        private string ValidateString(string? str)
        {
            if (string.IsNullOrWhiteSpace(str))
            {
                throw new ArgumentException("Вы ничего не ввели.");
            }
            else
            {
                return str;
            }
        }
    }
}
